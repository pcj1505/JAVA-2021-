package cafe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class management extends JFrame {
	String column[] = { "menu", "Price", "Quantity" };
	String column2[] = { "menu", "Price" };

	// ����Ʈ, ����, �����, ����, ���� ������ �޾ƿ�
	public management(String b[], int c[], int d[], String f[], int g[]) {
		// TODO Auto-generated constructor stub
		Font font = new Font(Font.SERIF, Font.BOLD, 12);
		Font font2 = new Font("���� ����", Font.BOLD, 12);
		setTitle("������ ���");
		setBackground(Color.DARK_GRAY);
		setBounds(480, 50, 500, 400);
		setResizable(false);
		setVisible(true);

		DefaultTableModel model = new DefaultTableModel(column, 0) {
			public boolean isCellEditable(int i, int c) {
				return false;
			} // ǥ ���� �Ұ�
		};
		JTable table = new JTable(model); // ����Ʈ
		JScrollPane scrollpane = new JScrollPane(table);
		for (int i = 0; i < b.length; i++) {
			String inputStr[] = new String[3];
			inputStr[0] = b[i];
			inputStr[1] = Integer.toString(c[i]);
			inputStr[2] = Integer.toString(d[i]);
			model.addRow(inputStr);
		}
		// ǥ ������
		table.setFont(font2);
		table.getTableHeader().setBackground(Color.DARK_GRAY);
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setFont(font);

		DefaultTableModel model2 = new DefaultTableModel(column2, 0) {
			public boolean isCellEditable(int i, int c) {
				return false;
			} // ǥ ���� �Ұ�
		};
		JTable table2 = new JTable(model2); // ����
		JScrollPane scrollpane2 = new JScrollPane(table2);
		for (int i = 0; i < f.length; i++) {
			String inputStr[] = new String[2];
			inputStr[0] = f[i];
			inputStr[1] = Integer.toString(g[i]);
			model2.addRow(inputStr);
		}
		// ǥ ������
		table2.setFont(font2);
		table2.getTableHeader().setBackground(Color.DARK_GRAY);
		table2.getTableHeader().setForeground(Color.WHITE);
		table2.getTableHeader().setFont(font);

		Panel add_12 = new Panel();
		add_12.setLayout(new GridLayout(0, 1));
		add_12.add(scrollpane2);
		add_12.add(scrollpane);

		Panel choice = new Panel();
		JButton Btn = new JButton("����Ʈ �߰��ϱ�");
		JButton Btn2 = new JButton("���� �߰��ϱ�");
		JButton Btn3 = new JButton("��� �߰�"); // �߰� �� �ڵ����� ����Ʈ 50�� ����
		JButton Btn4 = new JButton("�ݱ�");
		// ��ư ������
		Btn.setBackground(Color.DARK_GRAY);
		Btn.setForeground(Color.WHITE);
		Btn.setFont(font2);
		Btn2.setBackground(Color.DARK_GRAY);
		Btn2.setForeground(Color.WHITE);
		Btn2.setFont(font2);
		Btn3.setBackground(Color.DARK_GRAY);
		Btn3.setForeground(Color.WHITE);
		Btn3.setFont(font2);
		Btn4.setBackground(Color.DARK_GRAY);
		Btn4.setForeground(Color.WHITE);
		Btn4.setFont(font2);
		// �гο� ��ư �߰�
		choice.add(Btn);
		choice.add(Btn2);
		choice.add(Btn3);
		choice.add(Btn4);
		// �����ӿ� �߰�
		add(add_12, BorderLayout.CENTER);
		add(choice, BorderLayout.SOUTH);

		// ����Ʈ �߰�
		Btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new desert();
			}
		});

		// ���� �߰�
		Btn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new drink();
			}
		});
		// ��� �߰� ��ư ----- ������ �׳� ����Ʈ ���� �� 50���� ����
		Btn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DB_Conn_Query add_q = new DB_Conn_Query();
				add_q.sql_qadd();
				dispose();
				new CAFE_program();
			}
		});
		// �ݱ� ��ư
		Btn4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose(); // ������ â �ݱ�
			}
		});
	}

}
